import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ConformSerService {

  constructor(private http:HttpClient) { }

   SendKeer(objects){
     
     return this.http.post("http://10.230.174.247:1214/paymentBill/",objects)
    
    }


}
