import { TestBed } from '@angular/core/testing';

import { ConformSerService } from './conform-ser.service';

describe('ConformSerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ConformSerService = TestBed.get(ConformSerService);
    expect(service).toBeTruthy();
  });
});
