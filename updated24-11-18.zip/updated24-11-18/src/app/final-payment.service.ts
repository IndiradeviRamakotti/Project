import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class FinalPaymentService {

  constructor(private http:HttpClient) { }
  payments(obj){
    console.log(obj);
    return this.http.post("http://10.230.174.247:1214/paymentSucess/",obj,{responseType:'text' as 'text'});
  }
}
