import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {UserdashService} from '../userdash.service';
import * as $ from 'jquery';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css'],
  providers:[UserdashService]
})
export class UserDashboardComponent implements OnInit {
  userIds:string;
  obj:any=[];
  loadChild = false;
  constructor(private route:ActivatedRoute,private services:UserdashService,private router:Router,public authService: AuthService) { }
  search:any=[];
  polID:any;
  result=false;
  id:string;
  btnValue:string;
  gowtham:any;
  nancy:any;
  jenny:any;
  message:string;
  ngOnInit() {
    this.obj = [];
   this.userIds = this.route.snapshot.paramMap.get('userId');
   console.log(this.userIds);
   this.id = localStorage.getItem('token');
   this.services.sendParams(this.userIds).subscribe((response) =>{
     this.obj = response;
     if(this.obj["message"]!=null){
        this.nancy = this.obj;
     }else{
       this.jenny = this.obj;
     }
     console.log(this.obj);
   });
   this.services.scrollBar().subscribe((res)=>{
     this.gowtham = res;
     console.log(this.gowtham);
   })
  }

  call(){
     this.loadChild = true;
     this.result=true;
  }
  
 logout(){
  console.log("Logout");
  this.authService.logout();
  this.router.navigate(['Signin'])
 }
  objs($event){
   this.search = $event;

  }

   funcall(btn){
     this.btnValue = this.search[btn].policyId
    
     this.router.navigate(['Conform',{ policyIds:this.btnValue,
      userid:this.userIds}]);
   }


}
