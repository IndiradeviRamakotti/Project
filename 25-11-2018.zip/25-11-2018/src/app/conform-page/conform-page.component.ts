import { Component, OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConformSerService } from '../conform-ser.service';
import swal from 'sweetalert';
import { Location } from '@angular/common';
@Component({
  selector: 'app-conform-page',
  templateUrl: './conform-page.component.html',
  styleUrls: ['./conform-page.component.css'],
  providers:[ConformSerService]
})
export class ConformPageComponent implements OnInit {
  val1:string;
  val2:string;
  objects:any;
  obj:any;
  result=false;
  gowtham:any;
  msg:any;
  userId:any;
  constructor(private route:ActivatedRoute,private ser: ConformSerService,private router:Router,private location: Location) { }
  
  ngOnInit() { 
    this.val1 = this.route.snapshot.paramMap.get('policyIds');
    this.val2 = this.route.snapshot.paramMap.get('userid');
    this.objects = {
      user:this.val2,
      policy:this.val1
    }
    this.ser.SendKeer(this.objects).subscribe((response) => {
      this.obj = response;

      console.log(this.obj);
      if(this.obj["message"]== null){
        this.gowtham = this.obj;
        console.log("Iam a obj");
      }else{
        msg:this.obj["message"];
        swal("Sorry..!",this.obj["message"],"error");
       // this.router.navigate([''])
       this.location.back();
      }
    })
  }

  callPay(){
  this.result = true;
 
}


     
}
