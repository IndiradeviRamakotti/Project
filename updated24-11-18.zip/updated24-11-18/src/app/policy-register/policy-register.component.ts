import { Component, OnInit } from '@angular/core';
import { policyRegisterses } from '../interfaces';
import swal from 'sweetalert';
import { Router } from '@angular/router';
import { PolicymappingService } from '../policymapping.service';

@Component({
  selector: 'app-policy-register',
  templateUrl: './policy-register.component.html',
  styleUrls: ['./policy-register.component.css'],
  providers:[PolicymappingService]
})
export class PolicyRegisterComponent implements OnInit {
  policyName: String;
  startDate: String;
  duration: String;
  intialDeposit: String;
  t: String;
  t1: String;
  policyType:string;
  termsPerYear: String;
  termAmount: String;
  interest: String;
  val:string;
  company:object;
  type:object;
 check1:boolean;
 check2:boolean;
 check3:boolean;
 check4:boolean;
 check5:boolean;
 check6:boolean;
 arr = [];
 gow:string;
 message:string;
 num:number;
 i = 0;
 objs:any=[];
 val1 :boolean = true;
  constructor(private services:PolicymappingService,private route:Router) { }
 
  PolicyRegister() {
    if(this.check1 == true){
     this.arr[this.i++] = 11;
    }else if(this.check2 == true){
      this.arr[this.i++] = 12;
     // console.log(this.arr[0]);
    }else if(this.check3 == true){
      this.arr[this.i++] = 13;
    }else if(this.check4 == true){
      this.arr[this.i++] = 14;
    }else if(this.check5 == true){
      this.arr[this.i++] = 15;
    }else if(this.check6 == true){
      this.arr[this.i++] = 16;
    }
    this.arr.sort();
    this.t1 = this.arr[0];
   // console.log(this.t1);
   // console.log(this.policyType);
    const policyRegis: policyRegisterses = {
      policyName: this.policyName,
      startDate: this.startDate,
      duration: this.duration,
      intialDeposit: this.intialDeposit,
     // t:this.t, // company name
      policyType:this.policyType,
     // t1: this.t1, // userType
      company:{"companyId":this.t},
      type:{"typeid":this.t1},
      termsPerYear: this.termsPerYear,
      termAmount: this.termAmount,
      interest: this.interest
    }
    console.log(this.startDate);
    if(this.policyName!=undefined && this.policyType!=undefined && this.t!=undefined && this.t1!=undefined && this.startDate!=undefined && this.duration!=undefined && this.termsPerYear!=undefined && this.termAmount!=undefined && this.intialDeposit!=undefined && this.interest!=undefined){
      console.log(policyRegis);
      this.services.policyRegistering(policyRegis).subscribe((response)=> {
        this.val = response;
     // console.log(this.val);
      this.Display(this.val);
      })
    }
    
   
  }
  
  Display(msg){
      
      this.message = msg;
       if(this.message.substring(0,3) === "The"){
         this.route.navigate(['AdminDash']);
     swal("Success ..! ",this.message, "success");
       }else{
         swal("Sorry...! ","error");
       }
  }


  ngOnInit() {
    this.services.companyName().subscribe((response) => {
      this.objs = response;
    })
  }

}
