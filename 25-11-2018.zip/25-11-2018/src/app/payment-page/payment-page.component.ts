import { Component, OnInit, Input } from '@angular/core';
import { FinalPaymentService } from '../final-payment.service';
import swal from 'sweetalert';
import { Router } from '@angular/router';
@Component({
  selector: 'app-payment-page',
  templateUrl: './payment-page.component.html',
  styleUrls: ['./payment-page.component.css'],
  providers:[FinalPaymentService]
})
export class PaymentPageComponent implements OnInit {
   obj:any=[];
   gow:string;
   @Input() childMessage: any=[];
  constructor(private ser:FinalPaymentService,private route:Router) { }
   sasi:string;
    
  ngOnInit() {
    
  }
 payment(){
 // console.log(this.childMessage);
 //console.log(this.user);
     this.ser.payments(this.childMessage).subscribe((response) => {
       this.gow = response;
       swal("Success..!",this.gow,"success");
      //  var user = JSON.parse(this.childMessage);
      //  console.log(user.userId);
          this.sasi = this.childMessage["userId"];
          console.log(this.sasi);
         this.route.navigate(['UserDashboard/',this.sasi]);
       console.log(this.gow);
     })
 }
}
